import os

def main():
    os.system("streamlit run ui.py")

if __name__ == "__main__":
    main()